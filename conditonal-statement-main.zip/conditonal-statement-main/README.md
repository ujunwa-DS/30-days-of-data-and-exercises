# conditonal-statement
The if and else statement is very important if you are going to very helpful to you if you are learning data science or anything python in general.   
