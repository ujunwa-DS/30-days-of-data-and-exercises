# numpy-and-pandas
As a data scientist, one of the important tools you need is numpy and pandas. this repository throws light into it. 
